export interface CreateInvestmentDto {
  amount: number;
  duration: number;
  plan: string;
}